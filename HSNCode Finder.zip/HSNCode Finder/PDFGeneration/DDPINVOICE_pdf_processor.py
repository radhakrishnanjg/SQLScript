import json
import os 
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER,TA_LEFT,TA_RIGHT
from reportlab.lib.styles import ParagraphStyle
from PIL import Image as PILImage
import logging

from PDFGeneration.Invoice_PDFCreator import Invoice_PDFCreator
from sql_helper import SQLHelper

class DDPINVOICE_pdf_processor:
    def __init__(self):   
        self.sql_helper = SQLHelper()
        self.logger = logging.getLogger(self.__class__.__name__)  
        self.OUTPUT_FOLDER_DDPINVOICE = os.getenv("OUTPUT_FOLDER_DDPINVOICE", "") 
        self.OUTPUT_FOLDER_DDPINVOICE_SIGNATURE = os.getenv("OUTPUT_FOLDER_DDPINVOICE_SIGNATURE", "") 
        
        if not self.OUTPUT_FOLDER_DDPINVOICE or not self.OUTPUT_FOLDER_DDPINVOICE_SIGNATURE:
            raise ValueError("OUTPUT_FOLDER_DDPINVOICE and OUTPUT_FOLDER_DDPINVOICE_SIGNATURE not set in environment variables.")
    def process_files(self,company_id: int, file_type: str) -> None:
        try: 
            
            rows = self.sql_helper.execute_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessSearch",
                (company_id, file_type)
            )
            self.logger.info(f"Total files to process: {len(rows)}")
             
            #print(f"company_id {company_id} file_type {file_type}")
            if not rows:
                self.logger.info("No records found to process.")
                #print(f"No records found to process.")
                return
 
            hsn_code_ids = ','.join(str(row.ParentId) for row in rows)
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "UpdateIsProcessing_DDP",
                    "ParentIds":  str(hsn_code_ids)
                }
            )
            #print(f"hsn_code_ids {hsn_code_ids}")
            self.logger.info("Marked IDs as processing.")
            
            
            for index, row in enumerate(rows, start=1): 
                try: 
                    # Ensure conversion to int, default to 0 if None or invalid
                    ParentId: int = int(getattr(row, 'ParentId', 0) or 0)
                    LoginId: int = int(getattr(row, 'LoginId', 0) or 0)
                    #print(f"inside ParentId {ParentId}")
                    FileName = getattr(row, 'FileName', '')    

                    #print(f"ParentId {ParentId} LoginId {LoginId}")

                    rows_json=''
                    rows_json = self.sql_helper.execute_stored_procedure(
                        "Purchase.usp_DDPInvoice_SearchByID",(ParentId,LoginId) 
                    )   
                    json_string =''
                    for item in rows_json: 
                        json_string += item[0]
                    
                    
                    # print(f"json_string {json_string} ")
                    
                    data_dict = json.loads(json_string)
                    self.createPdffile(FileName,data_dict,file_type,ParentId)
                    
                    self.sql_helper.execute_json_stored_procedure(
                                "Catalogue.usp_PDFGeneration_ProcessAction",
                                {
                                    "Action": "UpdateIsProcessed_DDP",
                                    "ParentId": ParentId
                                }
                            )
                    self.logger.info(f"Marked ParentId {ParentId} as processed.")
                except Exception as e:
                    self.sql_helper.execute_json_stored_procedure(
                    "Catalogue.usp_PDFGeneration_ProcessAction",
                    {
                        "Action": "InsertInvoiceFileLog_DDP",
                        "StackTrace": str(e),
                        "MessageText": "Some Python code Error",
                        "ParentType": "DDPINVOICE",
                        "ParentId": ParentId,
                    }
                    )
                    self.logger.error(f"An error occurred during processing: {e}") 
                        
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "Update_RemovingIsProcessing_DDP",
                    "ParentIds": hsn_code_ids
                }
            )
            self.logger.info("Removed processing flags from ParentIds.")
            
        except Exception as e:
            self.sql_helper.execute_json_stored_procedure(
                    "Catalogue.usp_PDFGeneration_ProcessAction",
                    {
                        "Action": "InsertInvoiceFileLog_DDP",
                        "StackTrace": str(e),
                        "MessageText": "Some Python code Error",
                        "ParentType": "DDP",
                        "ParentId": ParentId
                    }
                    )
            self.logger.error(f"An error occurred during processing: {e}") 
        
    def createPdffile(self,FileName : str, data :str,file_type :str,ParentId :int)->None:
        try:   
            # print(f"data {data}")
            
            # Create PDF file
            if file_type == "DDPINVOICE" :
                pdf_filename = self.OUTPUT_FOLDER_DDPINVOICE + FileName +".pdf"  
                # print(pdf_filename)
            doc = SimpleDocTemplate(pdf_filename, pagesize=A4, bottomMargin=50)
            elements = []
            styles = getSampleStyleSheet()

            # Function to wrap text
            def wrap_text(text,style):
                return Paragraph(text, style) 
  
             
            
            styles = getSampleStyleSheet() 
            common_style = ParagraphStyle(
                'CommonStyle',
                parent=styles["Normal"],
                fontName="Courier",
                fontSize=8,
                leading=10,   
                alignment=TA_LEFT,
                spaceAfter=5
            )

            elements = [] 

            heading = Paragraph("<b>DDP Duty Reimbursement Invoice </b>", styles["Title"])
            elements.append(heading)
            elements.append(Spacer(1, 10))  
            
            header_data = [
            [ 
                Paragraph("<b>Invoice No :</b> " + data["InvoiceNumber"] + "       "    + "<b> Invoice Date :</b> " + data["InvoiceDate"].replace("T", " "), common_style),
                ""
            ], 
            [
                Paragraph("<b><u>CONSIGNOR/ SHIP FROM :</u></b><br/>" + data["ConsignorName"] + "<br/>" + "", common_style), 
                Paragraph("<b><u>IMPORTER LOCATION AS PER BOE :</u></b><br/>" + data["ConsigneeAddress"] + "<br/>"
                        + "<b>Email :</b> " + "Finance@valuecart.in", common_style), 
            ],   
            [  
                Paragraph("<b><u>PAYMENT DETAILS :</u></b><br/>"
                        + "<b> Beneficiary Name & Address :</b> " + str(data.get("BeneficiaryName", "")) + "<br/>"  + str(data.get("BeneficiaryAddress", "")) + " <br/>"  
                        + "<b> Beneficiary Bank's Name & Address :</b> " + str(data.get("BeneficiaryBankName", "")) + "<br/>"   
                        + "<b> Account Number :</b> " + str(data.get("AccountNumber", "")) + " <br/>"  
                        + "<b> SWIFT Code :</b> " + str(data.get("SWIFTCode", "")) + " <br/>" 
                        + "<b> Seller ID: </b>" + str(data.get("MarketPlaceSellerID", "")) +" <br/>"  
                        , common_style),
                
                Paragraph("<b><u>REMARKS :</u></b><br/>"
                        + "<b>Exchange Rate :</b> (1 USD to INR: " + str(data.get("ExchangeRate", "")) + " ) <br/>"   
                        , common_style),  
            ],  
        ]

            header_table = Table(header_data, colWidths=[590/2, 590/2])
            header_table.setStyle(TableStyle([ 
                ("SPAN", (0, 0), (-1, 0)),   
                ("ALIGN", (0, 0), (-1, 0), "RIGHT"),  # First row right-aligned
                ("ALIGN", (0, 0), (-1, 1), "CENTER"),   
                ("VALIGN", (0, 0), (-1, -1), "TOP"),  
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ]))

            elements.append(header_table)
            elements.append(Spacer(1, 10))
 
            table_data = [[
                "#"
                ,wrap_text("Description",common_style)
                ,wrap_text("BOE Number",common_style)
                ,wrap_text("Shipment ID"	,common_style) 
                ,wrap_text("Total Duty Value in INR",common_style)
                ,wrap_text("Total duty Value in USD",common_style)
            ]]

            # **Table Content** 
            total_DutyAmountINR = 0 
            total_DutyAmountUSD = 0 

            for item in data["lstInvoiceDetail"]:
                SLNo = int(item.get("SlNo", 0)) 
                DutyAmountINR = float(item.get("DutyAmountINR", 0))
                DutyAmountUSD = float(item.get("DutyAmountUSD", 0)) 
                total_DutyAmountINR+= DutyAmountINR
                total_DutyAmountUSD += DutyAmountUSD

                table_data.append([
                    SLNo,
                    Paragraph(str(item.get("Descriptions", "N/A"))  , common_style), 
                    Paragraph(str(item.get("BOENumber", "N/A")), common_style),
                    Paragraph(str(item.get("ShipmentNumber", "N/A")), common_style),  
                    f"{DutyAmountINR:.2f}",
                    f"{DutyAmountUSD:.2f}", 
                ])

            # **Add Total Row**
            table_data.append(["","", "Total", "",  f"{total_DutyAmountINR:.2f}",  f"{total_DutyAmountUSD:.2f}"])

            # **Create Table**
            table = Table(table_data, colWidths=[50, 140, 100,100, 100, 100])
            table.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, 1), 8),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("BACKGROUND", (0, -1), (-1, -1), colors.lightgrey),
            ]))

            elements.append(table)
            elements.append(Spacer(1, 10))

            # **Footer Text**
            footer_text = Paragraph("<b>Amount in words (USD): </b>" + str(data.get("AmountInwords", "")), common_style)

            # **Load Signature Image**
            signature_path = self.OUTPUT_FOLDER_DDPINVOICE_SIGNATURE + data.get("VendorSignature", "")
            signature_path = os.path.abspath(signature_path)

            if os.path.exists(signature_path):
                signature1 = Image(signature_path, width=3*inch, height=0.8*inch)
            else:
                signature1 = ""

            # **Footer Table with Signature**
            footer_data = [
                [footer_text], 
                [Paragraph("<b>For:</b>" + "<br/> <br/> " , common_style),""],
                [signature1,""],
                [Paragraph("<b>Authorised Signatory</b>", common_style),""],
                
            ]

            footer_table = Table(footer_data, colWidths=[400, 190])
            footer_table.setStyle(TableStyle([ 
                ("GRID", (0, 0), (-1, -1), 1, colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ]))

            elements.append(footer_table)

       
            # **Build PDF**
            doc.build(elements)
            print(f"PDF generated: {pdf_filename}") 
        except Exception as e: 
                
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "InsertInvoiceFileLog_DDP" ,
                    "StackTrace": str(e),
                    "MessageText": "Some Python code Error", 
                    "ParentType": file_type,
                    "ParentId": ParentId,
                }
            )
            self.logger.error(f"An error occurred during processing: {e}") 
 