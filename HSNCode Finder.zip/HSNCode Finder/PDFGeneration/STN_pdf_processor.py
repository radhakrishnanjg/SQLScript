import json
import os 
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from PIL import Image as PILImage
import logging

from sql_helper import SQLHelper

class STN_pdf_processor:
    def __init__(self):   
        self.sql_helper = SQLHelper()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        self.OUTPUT_FOLDER_STN = os.getenv("OUTPUT_FOLDER_STN", "") 
        self.OUTPUT_FOLDER_VALUECARTSIGNATURE = os.getenv("OUTPUT_FOLDER_VALUECARTSIGNATURE", "") 
        if not self.OUTPUT_FOLDER_STN or not self. OUTPUT_FOLDER_VALUECARTSIGNATURE:
            raise ValueError("OUTPUT_FOLDER_STN and OUTPUT_FOLDER_VALUECARTSIGNATURE not set in environment variables.")

    def process_files(self,company_id: int, file_type: str) -> None:
        try: 
            
            rows = self.sql_helper.execute_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessSearch",
                (company_id, file_type)
            )
            self.logger.info(f"Total files to process: {len(rows)}")

            if not rows:
                self.logger.info("No records found to process.")
                return

            hsn_code_ids = ','.join(str(row.ParentId) for row in rows)
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "UpdateIsProcessing_STN",
                    "ParentIds": hsn_code_ids
                }
            )
            self.logger.info("Marked IDs as processing.")
             
            for index, row in enumerate(rows, start=1):
                try: 
                    # Ensure conversion to int, default to 0 if None or invalid
                    ParentId: int = int(getattr(row, 'ParentId', 0) or 0)
                    SellerFormID: int = int(getattr(row, 'SellerFormID', 0) or 0)
                    
                    FileName = getattr(row, 'FileName', '')    

                    print(f"ParentId {ParentId} SellerFormID {SellerFormID}")

                    rows_json=''
                    try:
                        rows_json = self.sql_helper.execute_stored_procedure(
                            "Seller.usp_Package_SKU_Print",(ParentId, SellerFormID) 
                        )  

                        # print(rows_json) 
                        
                        json_string =''
                        for item in rows_json: 
                            json_string += item[0] 
                        # print(f"json_string {json_string}")
                        
                        data_dict = json.loads(json_string)   
                        
                        
                        self.createPdffile(FileName,data_dict,ParentId)
                    except Exception as e:
                        print(f"An unexpected error occurred: {e}")
                        self.logger.error(f"An error occurred during processing: {e} ParentId {ParentId}") 
                    self.sql_helper.execute_json_stored_procedure(
                                "Catalogue.usp_PDFGeneration_ProcessAction",
                                {
                                    "Action": "UpdateIsProcessed_STN",
                                    "ParentId": ParentId
                                }
                            )
                    self.logger.info(f"Marked ParentId {ParentId} as processed.")
                except Exception as e:
                    self.sql_helper.execute_json_stored_procedure(
                    "Catalogue.usp_PDFGeneration_ProcessAction",
                        {
                            "Action": "InsertInvoiceFileLog_STN",
                            "StackTrace": str(e),  # Convert exception to string
                            "MessageText": "Some Python File Error",
                            "ParentType": "STN",
                            "ParentId": ParentId
                        }
                    )
                    self.logger.error(f"An error occurred during processing: {e} ParentId {ParentId}") 
                        
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "Update_RemovingIsProcessing_STN",
                    "ParentIds": hsn_code_ids
                }
            )
            self.logger.info("Removed processing flags from HSNCodeIds.")
            
        except Exception as e:  
            self.sql_helper.execute_json_stored_procedure(
                              "Catalogue.usp_PDFGeneration_ProcessAction",
                                {
                                    "Action": "InsertInvoiceFileLog_STN",
                                    "StackTrace": str(e),
                                    "MessageText": "Some Python File Error",
	                                "ParentType": "STN",
                                    "ParentId": ParentId
                                }
                            )
            self.logger.error(f"An error occurred during processing: {e}") 

    def createPdffile(self,FileName : str, data :str,ParentId :int)->None:
        try:   
            # print(f"data {data}")
            
            # Create PDF file
            pdf_filename = self.OUTPUT_FOLDER_STN + FileName +".pdf"
            doc = SimpleDocTemplate(pdf_filename, pagesize=A4, bottomMargin=50)
            elements = []
            styles = getSampleStyleSheet()

            # Function to wrap text
            def wrap_text(text,style):
                return Paragraph(text, style) 
            styles = getSampleStyleSheet()

            # **Define a Common Paragraph Style for All Text**
            common_style = ParagraphStyle(
                'CommonStyle',
                parent=styles["Normal"],
                fontName="Courier",
                fontSize=8,
                leading=10,  # Line spacing
                paddingleft=10,  # Line spacing
                alignment=TA_LEFT,
                spaceAfter=5
            )

            # **Document Elements List**
            elements = []

            # **Heading**
            heading = Paragraph("<b>DELIVERY CHALLAN/STN/PACKING LIST</b>", styles["Title"])
            elements.append(heading)
            elements.append(Spacer(1, 10))

             # **Table Headers**
            table_data = [[
                "#", "PRODUCT DETAILS", "MRP", "QTY", "BOX #", "WT(KG)"
            ]]

            # **Table Content**
            total_qty = 0
            total_mrp = 0
            total_weight_per_unit = 0

            for item in data["lstPackageDetail"]:
                qty = int(item["Qty"])  
                mrp = float(item.get("MRPInINR", 0))  
                weight_per_unit = float(item.get("WeightPerUnit", 0)) * qty
                total_qty += qty
                total_mrp += mrp
                total_weight_per_unit += weight_per_unit

                table_data.append([
                    item["SNo"], 
                    Paragraph("<b>Product : </b>" + item.get("ProductDescription", "N/A") + "<br/>" + 
                              "<b>MerchantSKU : </b>" + item.get("MerchantSKU", "N/A") + "<br/>" + 
                              "<b>FNSKU : </b>" + item.get("FNSKU", "N/A") + " " +" <b>ASIN : </b>" + item.get("ASIN", "N/A") , common_style),
                    f"{mrp:.2f}",
                    qty,
                    wrap_text(str(item["BoxNumbers"]),common_style), 
                    f"{weight_per_unit:.4f}",
                ])
                
            # **Header Table**
            header_data = [
                [Paragraph("<b> Ship From:</b>",common_style), wrap_text(data["ShipFromAddress"],common_style)],
                [Paragraph("<b> GSTIN:</b>",common_style), wrap_text(data["GSTIN"],common_style)],
                [Paragraph("<b> Ship To:</b>",common_style), wrap_text(data["ShipToAddress"],common_style)],
                [Paragraph("<b> Shipment ID:</b>",common_style), wrap_text(data["FBAShipmentID"],common_style)],
                [Paragraph("<b>Total No. of Boxes:</b>", common_style), Paragraph(str(data["NoOfBoxes"]), common_style)],
                [Paragraph("<b>Total Weight:</b>", common_style), Paragraph(f"{total_weight_per_unit:.2f}", common_style)],
            ]

            header_table = Table(header_data, colWidths=[70, 520])
            header_table.setStyle(TableStyle([
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ]))

            elements.append(header_table)
            elements.append(Spacer(1, 10))
 

            # **Add Total Row**
            table_data.append(["", "Total","", total_qty, "", f"{total_weight_per_unit:.2f}" ])

            # **Create Table**
            table = Table(table_data, colWidths=[20, 360, 70, 40, 40, 60])
            table.setStyle(TableStyle([
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, 0), 8),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("BACKGROUND", (0, -1), (-1, -1), colors.lightgrey),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ]))

            elements.append(table) 
            elements.append(Spacer(1, 10))

            # **Footer Text**
            footer_text = Paragraph(
                "Note: The above-mentioned goods are being transferred from our primary place of business to an additional place of business.<br/>"
                "That said, the movement of goods between our branches is a stock transfer and hence not a transaction.<br/>"
                "The above-mentioned details are true and correct to the best of our knowledge.",
                common_style
            )

            # **Load Signature Image**
            signature_path = self.OUTPUT_FOLDER_VALUECARTSIGNATURE  
            signature_path = os.path.abspath(signature_path)

            if os.path.exists(signature_path):
                signature1 = Image(signature_path, width=3*inch, height=0.8*inch)   
            else:
                signature1 = ""

            # **Footer Table with Signature**
            footer_data = [
                [footer_text],
                [Spacer(1, 10)],
                [" For"],
                [Spacer(1, 20)],
                [signature1],
                [" Authorised Signatory"]
            ]

            footer_table = Table(footer_data, colWidths=[590])
            footer_table.setStyle(TableStyle([
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
                ("TOPPADDING", (0, 0), (-1, -1), 0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                ("BACKGROUND", (0, 0), (-1, -1), colors.white),  # Ensure no background color
                ("LINEBELOW", (0, 0), (-1, -1), 0, colors.white),  # Hide bottom line
                ("LINEABOVE", (0, 0), (-1, -1), 0, colors.white),  # Hide top line
                ("LINELEFT", (0, 0), (-1, -1), 0, colors.white),  # Hide left line
                ("LINERIGHT", (0, 0), (-1, -1), 0, colors.white),  # Hide right line
            ]))
 

            elements.append(footer_table)

            # **Build PDF**
            doc.build(elements)
            print(f"PDF generated: {pdf_filename}") 
        except Exception as e:
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.n",
                {
                    "Action": "InsertInvoiceFileLog_STN",
                    "StackTrace": str(e),
                    "MessageText": "Some Python code Error", 
                    "ParentType": "STN",
                    "ParentId": ParentId
                }
            )
            self.logger.error(f"An error occurred during processing: {e}") 