import json
import os 
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from PIL import Image as PILImage
import logging

from PDFGeneration.Invoice_PDFCreator import Invoice_PDFCreator
from sql_helper import SQLHelper

class SINGLEINVOICE_pdf_processor:
    def __init__(self):   
        self.sql_helper = SQLHelper()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.OUTPUT_FOLDER_INVOICE = os.getenv("OUTPUT_FOLDER_INVOICE", "") 
        self.OUTPUT_FOLDER_INVOICE_SIGNATURE = os.getenv("OUTPUT_FOLDER_INVOICE_SIGNATURE", "") 
        
        if not self.OUTPUT_FOLDER_INVOICE or not self.OUTPUT_FOLDER_INVOICE_SIGNATURE:
            raise ValueError("OUTPUT_FOLDER_INVOICE and OUTPUT_FOLDER_INVOICE_SIGNATURE not set in environment variables.") 

    def process_files(self,company_id: int, file_type: str) -> None:
        try: 
            
            rows = self.sql_helper.execute_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessSearch",
                (company_id, file_type)
            )
            self.logger.info(f"Total files to process: {len(rows)}")

            if not rows:
                self.logger.info("No records found to process.")
                return

            hsn_code_ids = ','.join(str(row.ParentId) for row in rows)
            InvoiceNos = ','.join(str(row.FileName) for row in rows)
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "UpdateIsProcessing",
                    "ParentIds": hsn_code_ids,
                    "InvoiceNos": InvoiceNos,
                }
            )
            self.logger.info("Marked IDs as processing.")
            
            for index, row in enumerate(rows, start=1):
                try:
                    # Ensure conversion to int, default to 0 if None or invalid
                    ParentId: int = int(getattr(row, 'ParentId', 0) or 0)
                    SellerFormID: int = int(getattr(row, 'SellerFormID', 0) or 0)
                    
                    FileName = getattr(row, 'FileName', '')    

                    print(f"ParentId {ParentId} SellerFormID {SellerFormID}")

                    print(f"ParentId {ParentId} FileName {FileName}")
                    rows_json=''
                    rows_json = self.sql_helper.execute_stored_procedure(
                        "Seller.usp_Package_Invoice_Print",(ParentId,FileName) 
                    )    
                    
                    json_string =''
                    for item in rows_json: 
                        json_string += item[0]
                        
                    
                    data_dict = json.loads(json_string)    
                    
                    Invoice_PDFCreator.createPdffile(self,FileName,data_dict,file_type,ParentId)
                    
                    self.sql_helper.execute_json_stored_procedure(
                                "Catalogue.usp_PDFGeneration_ProcessAction",
                                {
                                    "Action": "UpdateIsProcessed",
                                    "ParentId": ParentId,
                                    "InvoiceNo": FileName,
                                }
                            )
                except Exception as e:
                    self.sql_helper.execute_json_stored_procedure(
                    "Catalogue.usp_PDFGeneration_ProcessAction",
                    {
                        "Action": "InsertInvoiceFileLog",
                        "StackTrace": str(e),
                        "MessageText": "Some Python code Error",
                        "ParentType": "SINGLEINVOICE",
                        "ParentId": ParentId
                    }
                    )
                    self.logger.error(f"An error occurred during processing: {e}")  
                        
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": "Update_RemovingIsProcessing",
                    "ParentIds": hsn_code_ids,
                    "InvoiceNos": InvoiceNos,
                }
            )
            self.logger.info("Removed processing flags from HSNCodeIds.")
            
        except Exception as e:
            self.sql_helper.execute_json_stored_procedure(
                    "Catalogue.usp_PDFGeneration_ProcessAction",
                    {
                        "Action": "InsertInvoiceFileLog",
                        "StackTrace": str(e),
                        "MessageText": "Some Python code Error",
                        "ParentType": "SINGLEINVOICE",
                        "ParentId": ParentId
                    }
                    )
            self.logger.error(f"An error occurred during processing: {e}")
            
 