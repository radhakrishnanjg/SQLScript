import json
import os 
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER,TA_LEFT,TA_RIGHT
from reportlab.lib.styles import ParagraphStyle
from PIL import Image as PILImage
import logging

from sql_helper import SQLHelper
 

class Invoice_PDFCreator:
    def __init__(self):    
        self.sql_helper = SQLHelper()
        self.logger = logging.getLogger(self.__class__.__name__)

        self.OUTPUT_FOLDER_INVOICE = os.getenv("OUTPUT_FOLDER_INVOICE", "") 
        self.OUTPUT_FOLDER_INVOICE_SIGNATURE = os.getenv("OUTPUT_FOLDER_INVOICE_SIGNATURE", "") 
        
        if not self.OUTPUT_FOLDER_INVOICE or not self.OUTPUT_FOLDER_INVOICE_SIGNATURE:
            raise ValueError("OUTPUT_FOLDER_INVOICE and OUTPUT_FOLDER_INVOICE_SIGNATURE not set in environment variables.")

 
    def createPdffile(self,FileName : str, data :str,InvoiceTye :str,ParentId :int)->None:
        try:   
            # print(f"data {data}")
            
            # Create PDF file
            if InvoiceTye == "SINGLEINVOICE" :
                pdf_filename = self.OUTPUT_FOLDER_INVOICE + FileName +".pdf"
            elif InvoiceTye== "CONSOLIDATEDINVOICE" :
                pdf_filename = self.OUTPUT_FOLDER_INVOICE + FileName +"_Con.pdf"
            # print(f"pdf_filename {pdf_filename}")
            doc = SimpleDocTemplate(pdf_filename, pagesize=A4, bottomMargin=50)
            elements = []
            styles = getSampleStyleSheet()

            # Function to wrap text
            def wrap_text(text,style):
                return Paragraph(text, style) 
  
             
            
            styles = getSampleStyleSheet()

            # **Define a Common Paragraph Style for All Text**
            common_style = ParagraphStyle(
                'CommonStyle',
                parent=styles["Normal"],
                fontName="Courier",
                fontSize=8,
                leading=10,  # Line spacing
                alignment=TA_LEFT,
                spaceAfter=5
            )

            elements = []


            heading_style = ParagraphStyle(
                'HeadingStyle',
                parent=styles["Normal"],
                fontName="Helvetica-Bold",
                fontSize=14,  # Bigger Font
                alignment=TA_RIGHT,
                spaceAfter=10
            )

            right_align_style = ParagraphStyle(
                'RightAlignStyle',
                parent=styles["Normal"],
                fontName="Helvetica",
                fontSize=10,  # Smaller size for Original/Duplicate/Triplicate
                alignment=TA_RIGHT,
                spaceAfter=5
            )

            # Create Paragraphs with styles
            heading1 = Paragraph("(Original/Duplicate/Triplicate)", right_align_style)
            heading2 = Paragraph("<b>COMMERCIAL INVOICE</b>", heading_style)

            # Use Table to align elements correctly
            header_table = Table([[heading2, heading1]], colWidths=[380, 210])   

            header_table.setStyle(TableStyle([
                ("ALIGN", (0, 0), (0, 0), "RIGHT"),  # Right align first column
                ("ALIGN", (1, 0), (1, 0), "CENTER"),  # Center align second column
                ("VALIGN", (0, 0), (-1, -1), "TOP"),  # Top align for vertical spacing
                ("FONTNAME", (1, 0), (1, 0), "Helvetica-Bold"),  # Bold for heading
            ]))

            # Add table to elements
            elements.append(header_table)
            elements.append(Spacer(1, 10)) 
            
            header_data = [
            [ 
                Paragraph("<b>Invoice No :</b> " + data["InvoiceNo"] + "<br/>"  
                        + "<b>Invoice Date :</b> " + data["InvoiceDate"].replace("T", " "), common_style),
                
                Paragraph("<b>Buyer's Order No.:</b> " + data["BuyerOrderNo"] + "<br/>"  
                        + "<b>Buyer Order Date :</b> " + data["BuyerOrderDate"].replace("T", " "), common_style)
            ],
            
            [
                Paragraph("<b><u>CONSIGNOR/ SHIP FROM :</u></b><br/>" + data["ConsignorName"] + "<br/>" + data["ConsignorAddress"], common_style), 
                Paragraph("<b><u>BILL FROM :</u></b><br/>" + data["BillFrom"], common_style), 
            ], 
            
            [
                Paragraph("<b><u>CONSIGNEE/ BILL TO :</u></b><br/>" + data["ConsigneeAddress"] + "<br/>"
                        + "<b>IEC :</b> " + data["IEC"] + "  <b>GSTIN :</b> " + data["GSTIN"]   + "<br/>" 
                        + "<b>Mobile No. :</b> " + data["MobileNumber"] + "  <b>Email :</b> " + "arun@valuecart.in" 
                        , common_style), 
                
                Paragraph("<b><u>SHIP TO/ DELIVERY TO :</u></b><br/>" + data["ShipTO"] + "<br/>" + str(data.get("ShipTOAddress", "")), common_style), 
            ],
            
            [ 
                Paragraph("<b><u>SHIPPING & TRADING DETAILS :</u></b><br/>"
                        + "<b>FROM :</b> " + data["ShipFromCountry"] + "<br/>"  
                        + "<b>TO :</b> " + data["ShipTOCountry"] + "<br/>"  
                        + "<b>Country Of Origin : </b>" + str(data.get("CountryName", "")) +"<br/>" 
                        + "<b>Port of Discharge :</b> " + data["Aircraft"] + "<br/>"   
                        + "<b>Trading Term :</b> " + data["TermsOfDelivery"] + "<br/>"   
                        + "<b>Shipping Remarks & No. :</b> " + data["ShippingRemarks"] + "<br/>"   
                        + "<b>Sailing on or about :</b> " + data["SailingOnOrAbout"]
                        , common_style), 
                
                Paragraph("<b><u>PAYMENT DETAILS :</u></b><br/>"
                        + "<b> Beneficiary Name & Address :</b> " + str(data.get("BeneficiaryName", "")) + "<br/>"  + str(data.get("BeneficiaryAddress", "")) + " <br/>"  
                        + "<b> Beneficiary Bank's Name & Address :</b> " + str(data.get("BeneficiaryBankName", ""))   + " <br/>"  
                        + "<b> AccountName :</b> " + str(data.get("AccountName", ""))   + " <br/>"  
                        + "<b> Account Number :</b>"   + str(data.get("AccountNumber", "")) + " <br/>"  
                        + "<b> SWIFT Code :</b> " + str(data.get("SWIFTCode", "")) + " <br/>" 
                        + "<b> Seller ID: </b>" + str(data.get("MarketPlaceSellerID", "")) +" <br/>" 
                        + "<b> V.Account No.: </b>" + str(data.get("CompanyDetailAccountNumber", ""))
                        , common_style),
            ],  
        ]

            header_table = Table(header_data, colWidths=[590/2, 590/2])
            header_table.setStyle(TableStyle([ 
                ("SPAN", (0, 0), (-1, 0)),   
                ("ALIGN", (0, 0), (-1, 0), "RIGHT"),  # First row right-aligned
                ("ALIGN", (0, 0), (-1, 1), "CENTER"),   
                ("VALIGN", (0, 0), (-1, -1), "TOP"),  
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ]))

            elements.append(header_table)
            elements.append(Spacer(1, 10))
 
            table_data = [[
                "#", "PRODUCT DETAILS", "HSN CODE", "QTY", wrap_text("UNIT PRICE (USD)",common_style), wrap_text("TOTAL VALUE (USD)",common_style)
            ]]

            # **Table Content**
            total_qty = 0
            total_TotalUnitValueInUSD = 0

            for item in data["lstInvoiceDetail"]:
                qty = int(item.get("Qty", 0))
                SLNo = int(item.get("SLNo", 0))
                UnitPerPriceInUSD = float(item.get("UnitPerPriceInUSD", 0))
                TotalUnitValueInUSD = float(item.get("TotalUnitValueInUSD", 0))
                total_qty += qty
                total_TotalUnitValueInUSD += TotalUnitValueInUSD

                table_data.append([
                    SLNo,
                    Paragraph("<b>Product : </b>" + item.get("ProductDescription", "N/A") + "<br/>" + 
                              "<b>MerchantSKU : </b>" + item.get("MerchantSKU", "N/A") + "<br/>" + 
                              "<b>FNSKU : </b>" + item.get("FNSKU", "N/A") + " " +" <b>ASIN : </b>" + item.get("ASIN", "N/A") , common_style), 
                    Paragraph(str(item.get("HSNCode", "N/A")), common_style),
                    qty,
                    f"{UnitPerPriceInUSD:.2f}",
                    f"{TotalUnitValueInUSD:.2f}",
                    
                ])

            # **Add Total Row**
            table_data.append(["", "Total", "", total_qty, "",  f"{total_TotalUnitValueInUSD:.2f}"])

            # **Create Table**
            table = Table(table_data, colWidths=[15, 325, 60, 50, 70, 70])
            table.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, 1), 8),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("BACKGROUND", (0, -1), (-1, -1), colors.lightgrey),
            ]))

            elements.append(table)
            elements.append(Spacer(1, 10))

            # **Footer Text**
            footer_text = Paragraph("<b>Amount in words (USD): </b>" + str(data.get("TotalAmuntWords", "")), common_style)

            # **Load Signature Image**
            signature_path = self.OUTPUT_FOLDER_INVOICE_SIGNATURE + data.get("VendorSignature", "")
            signature_path = os.path.abspath(signature_path)

            if os.path.exists(signature_path):
                signature1 = Image(signature_path, width=3*inch, height=0.8*inch)
            else:
                signature1 = ""

            # **Footer Table with Signature**
            footer_data = [
                [footer_text],
                # [Paragraph(
                #  "<b> COUNTRY OF ORIGIN: </b>" + str(data.get("CountryName", "")) +"<br/>" +
                #  "<b> Seller ID: </b>" + str(data.get("MarketPlaceSellerID", "")) +"<br/>" +
                #  "<b> Account No.: </b>" + str(data.get("CompanyDetailAccountNumber", "")) , common_style), 
                #  ""
                # ],
                [Paragraph("<b>For:</b>" + "<br/> <br/> " , common_style),""],
                [signature1,""],
                [Paragraph("<b>Authorised Signatory</b>", common_style),""],
                
            ]

            footer_table = Table(footer_data, colWidths=[400, 190])
            footer_table.setStyle(TableStyle([
                # ("SPAN", (0, 0), (-1, 0)),   
                # ("SPAN", (0, 2), (-1, 2)),   
                # ("SPAN", (0, 3), (-1, 3)),   
                ("GRID", (0, 0), (-1, -1), 1, colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Courier"),
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ]))

            elements.append(footer_table)

            # **Build PDF**
            doc.build(elements)
            print(f"PDF generated: {pdf_filename}") 
        except Exception as e:
            Action ='' 
            if InvoiceTye == "SINGLEINVOICE" :
                Action = "InsertInvoiceFileLog"
            elif InvoiceTye== "CONSOLIDATEDINVOICE" :
                Action = "InsertInvoiceFileLog_ConInvoice"
                
            self.sql_helper.execute_json_stored_procedure(
                "Catalogue.usp_PDFGeneration_ProcessAction",
                {
                    "Action": Action ,
                    "StackTrace": str(e),
                    "MessageText": "Some Python code Error", 
                    "ParentType": InvoiceTye,
                    "ParentId": ParentId 
                }
            )
            self.logger.error(f"An error occurred during processing: {e}") 