# OpenAI_HSNCode

Note : Don't use same db crdnetials and open ai keys which mentioned in the .env file

HSNCOde finder Description
Tariff Image Storage: All tariff images are uploaded to an Amazon S3 bucket.

Image-to-Text Conversion: Each image is processed with Textract, and the extracted text is saved as a JSON file in the same S3 bucket.

Reference Table Population: The JSON outputs are imported into the OpenAI.tariff_lines SQL table for reference.

HSN Classification Table: The OpenAI.HSNCodeDetail SQL table stores product images and descriptions that need HSN code classification.

Classification Logic:

Case 1: If the best match from tariff_lines has a score ≥ 0.8, use this HSN code directly.

Case 2: If the score is < 0.8, call the LLM to classify and provide a confidence score.

Result Update: The chosen HSNCode, TopSQLScore, and LLMConfidence are updated in the HSNCodeDetail table.

# Run the following commands for HSNCOde finder

Step 1:
python main.py --company_id 3 --file_type TARIFFS3ImagesTOJSON
Step 2:
python main.py --company_id 3 --file_type TARIFFS3JSONTODB
Step 3:
python main.py --company_id 3 --file_type HSNCODE

Server Path :
D:\DeployedCode\ConsoleApp\OpenAI_HSNCode

python main.py
