# sql_helper.py

import os
import pyodbc
import json
from typing import Any, List, Optional
import logging

class SQLHelper:
    def __init__(self):
        self.driver = os.getenv("DB_DRIVER", "{ODBC Driver 17 for SQL Server}")
        self.server = os.getenv("DB_SERVER", "")
        self.database = os.getenv("DB_DATABASE", "")
        self.username = os.getenv("DB_UID", "")
        self.password = os.getenv("DB_PWD", "")
        self.connection_string = f"""
        DRIVER={self.driver};
        SERVER={self.server};
        DATABASE={self.database};
        UID={self.username};
        PWD={self.password};
        Trust_Connection=yes;
        Encrypt=yes;
        TrustServerCertificate=yes;
        """
        self.logger = logging.getLogger(self.__class__.__name__)

    def execute_stored_procedure(self, proc_name: str, params: Optional[tuple] = None) -> List[Any]:
        """
        Executes a stored procedure and returns the fetched rows.
        """
        try:
            with pyodbc.connect(self.connection_string) as conn:
                with conn.cursor() as cursor:
                    self.logger.debug(f"Executing stored procedure: {proc_name} with params: {params}")
                    cursor.execute(f"{{CALL {proc_name} ({','.join(['?']*len(params))})}}", params)
                    rows = cursor.fetchall()
                    self.logger.debug(f"Fetched {len(rows)} rows.")
                    return rows
        except pyodbc.Error as e:
            self.logger.error(f"Error executing stored procedure {proc_name}: {e}")
            raise

    def execute_stored_procedure_no_return(self, proc_name: str, params: Optional[tuple] = None) -> None:
        """
        Executes a stored procedure that does not return any rows.
        """
        try:
            with pyodbc.connect(self.connection_string) as conn:
                with conn.cursor() as cursor:
                    self.logger.debug(f"Executing stored procedure: {proc_name} with params: {params}")
                    cursor.execute(f"{{CALL {proc_name} ({','.join(['?']*len(params))})}}", params)
                    conn.commit()
                    self.logger.debug("Transaction committed successfully.")
        except pyodbc.Error as e:
            self.logger.error(f"Error executing stored procedure {proc_name}: {e}")
            raise

    def execute_json_stored_procedure(self, proc_name: str, json_data: dict) -> None:
        """
        Executes a stored procedure that takes a JSON string as a parameter.
        """
        try:
            json_string = json.dumps(json_data)
            self.execute_stored_procedure_no_return(proc_name, (json_string,))
        except Exception as e:
            self.logger.error(f"Error executing JSON stored procedure {proc_name}: {e}")
            raise
