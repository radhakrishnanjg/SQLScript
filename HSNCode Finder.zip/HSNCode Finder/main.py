# main.py

import os
import sys
import logging
from dotenv import load_dotenv   
from HSNCODEProcess.textract_images_to_sql import HSNTextractPipeline
from PDFGeneration.DDPINVOICE_pdf_processor import DDPINVOICE_pdf_processor
from PDFGeneration.CONSOLIDATEDINVOICE_pdf_processor import CONSOLIDATEDINVOICE_pdf_processor
from PDFGeneration.SINGLEINVOICE_pdf_processor import SINGLEINVOICE_pdf_processor
from PDFGeneration.STN_pdf_processor import STN_pdf_processor 
from processor import HSNCodeProcessor
import pyodbc
import argparse
import time
def setup_logging():
    """
    Configures the logging settings.
    """
    logger = logging.getLogger()
    # logger.setLevel(logging.DEBUG)

    # Create handlers
    c_handler = logging.StreamHandler(sys.stdout)
    f_handler = logging.FileHandler('app.log')

    c_handler.setLevel(logging.ERROR)
    # f_handler.setLevel(logging.DEBUG)

    # Create formatters and add them to handlers
    c_format = logging.Formatter('%(levelname)s - %(message)s')
    f_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    c_handler.setFormatter(c_format)
    f_handler.setFormatter(f_format)

    # Add handlers to the logger
    logger.addHandler(c_handler)
    logger.addHandler(f_handler)

def parse_arguments():
    parser = argparse.ArgumentParser(description="Process HSN Codes based on Company ID and File Type.")
    parser.add_argument(
        "--company_id",
        type=int,
        default=None,  # Set to None to detect if the argument was provided
        help="ID of the company to process. If not provided, uses CURRENT_COMPANY_ID from environment variables."
    )
    parser.add_argument(
        "--file_type",
        type=str,
        default=None,  # Set to None to detect if the argument was provided
        help="Type of files to process (e.g., 'HSNCODE'). If not provided, uses CURRENT_FILE_TYPE from environment variables."
    )
    return parser.parse_args()

def main():
    """
    Main function to execute the HSN code processing.
    """
    try:
        # Load environment variables
        load_dotenv()

        # Parse command-line arguments current CompanyId and FileType
        args = parse_arguments()
        if args.company_id is not None and args.file_type is not None :
            current_company_id = args.company_id
            current_file_type = args.file_type
        else:
            current_company_id = int(os.getenv("CURRENT_COMPANY_ID", "3"))
            current_file_type = os.getenv("CURRENT_FILE_TYPE", "TARIFFS3ImagesTOJSON")

        # Initialize processor
        if args.file_type == "HSNCODE" or current_file_type =="HSNCODE":
            processor = HSNCodeProcessor()
            processor.process_files(current_company_id, current_file_type)
        elif args.file_type == "STN" or current_file_type =="STN" :
            pdfprocessor = STN_pdf_processor() 
            pdfprocessor.process_files(current_company_id, current_file_type)
        elif args.file_type == "SINGLEINVOICE" or current_file_type =="SINGLEINVOICE" :
            pdfprocessor = SINGLEINVOICE_pdf_processor() 
            pdfprocessor.process_files(current_company_id, current_file_type)
        elif args.file_type == "CONSOLIDATEDINVOICE" or current_file_type =="CONSOLIDATEDINVOICE" :
            pdfprocessor = CONSOLIDATEDINVOICE_pdf_processor() 
            pdfprocessor.process_files(current_company_id, current_file_type)
        elif args.file_type == "DDPINVOICE" or current_file_type =="DDPINVOICE" :
            pdfprocessor = DDPINVOICE_pdf_processor() 
            pdfprocessor.process_files(current_company_id, current_file_type)
        elif args.file_type == "TARIFFS3ImagesTOJSON" or current_file_type =="TARIFFS3ImagesTOJSON" :
            worker = HSNTextractPipeline()
            worker.process1_images_to_textract_json()
        elif args.file_type == "TARIFFS3JSONTODB" or current_file_type =="TARIFFS3JSONTODB" :
            # print(pyodbc.drivers())
            worker = HSNTextractPipeline()
            worker.process2_textract_jsons_to_db()
        else : 
            print(f"Invalid selection")
            
        # Define current CompanyId and FileType 
        print(f"current_company_id : {current_company_id} and current_file_type :{current_file_type}")
 

    except Exception as e:
        logging.error(f"An unhandled exception occurred: {e}")

if __name__ == "__main__":
    setup_logging()
    main()
