# processor.py
import json
import os
import re
import shutil
import logging
import base64
from io import BytesIO
from typing import Any, List, Dict, Tuple

import openai
import pytesseract
from PIL import Image
from sql_helper import SQLHelper

MIN_SQL_SCORE = 0.80  # threshold for accepting DB match (0..1.0)

class HSNCodeProcessor:
    def __init__(self):
        # --- OpenAI ---
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not found in environment variables.")
        openai.api_key = self.api_key

        # --- Folders ---
        self.input_folder = os.getenv("INPUT_FOLDER", "")
        self.output_folder = os.getenv("OUTPUT_FOLDER", "")
        self.OPENAI_VISION_MODEL = os.getenv("OPENAI_VISION_MODEL", "gpt-4o-mini")
        if not self.input_folder or not self.output_folder:
            raise ValueError("INPUT_FOLDER or OUTPUT_FOLDER not set in environment variables.")

        # --- Tesseract ---
        pytesseract.pytesseract.tesseract_cmd = os.getenv("TESSERACT_CMD", "tesseract.exe")
        if not os.path.exists(pytesseract.pytesseract.tesseract_cmd):
            raise FileNotFoundError(f"Tesseract executable not found at {pytesseract.pytesseract.tesseract_cmd}")

        # --- SQL Helper ---
        self.sql_helper = SQLHelper()

        # --- Logging ---
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            logging.basicConfig(
                level=logging.INFO,
                format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
            )
 

    def _file_to_data_url(self, image_path: str) -> str:
        """
        Load the image from disk and return a data URL suitable for OpenAI vision.
        Supports common formats; defaults mime as image/jpeg for jpg/jpeg and image/png for png.
        """
        ext = os.path.splitext(image_path)[1].lower()
        mime = "image/jpeg"
        if ext == ".png":
            mime = "image/png"
        elif ext in (".webp",):
            mime = "image/webp"
        elif ext in (".bmp",):
            mime = "image/bmp"

        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
        return f"data:{mime};base64,{b64}"


    def _normalize_for_search(self, s: str) -> str:
        """
        Light cleanup (printables + space squashing). Keeps punctuation helpful to codes.
        """
        s = (s or "").strip()
        s = re.sub(r"[^\x09\x0A\x0D\x20-\x7E]", " ", s)  # strip non-printables
        s = re.sub(r"\s+", " ", s)
        return s


    def extract_visual_context_from_image(self, image_path: str) -> str:
        """
        Vision-first extraction:
        1) Ask an OpenAI vision model to summarize what's in the image, including any
            visible text, codes, materials, functions, and domain cues.
        2) Return a compact, search-ready string.
        3) If anything fails, fall back to Tesseract OCR.
        """
        try:
            self.logger.debug(f"Vision OCR image: {image_path}")
            data_url = self._file_to_data_url(image_path)

            # Prompt tuned for customs/HSN use-cases
            system = (
                "You are an expert customs classifier assistant. "
                "Extract a compact, search-ready summary of what's in the image: "
                "1) a one-line product summary; "
                "2) any visible printed text (OCR-like); "
                "3) visible brand/model/part numbers; "
                "4) materials; "
                "5) principal function/end-use; "
                "6) domain cues that map to tariff headings (e.g., weighing machinery, pumps, bearings); "
                "7) any digit groups that look like 4/6/8-digit HSN-like codes. "
                "Be concise. No chit-chat; return plain text only."
            )

            user_content = [
                {"type": "text", "text": "Please analyze this product image for customs classification context."},
                {"type": "image_url", "image_url": {"url": data_url}}
            ]

            # OpenAI Chat Completions (vision) call
            resp = openai.ChatCompletion.create(
                model=self.OPENAI_VISION_MODEL,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_content}
                ],
                temperature=0.1,
                max_tokens=600
            )
            out = resp["choices"][0]["message"]["content"]
            return self._normalize_for_search(out)

        except Exception as e:
            self.logger.warning(f"Vision extraction failed, falling back to Tesseract. Reason: {e}")

            # ---- Fallback: Tesseract ----
            try:
                img = Image.open(image_path)
                text = pytesseract.image_to_string(img)
                return self._normalize_for_search(text)
            except Exception as e2:
                self.logger.error(f"OCR fallback error for {image_path}: {e2}")
                return ""

    # -------------------- Query building (in-memory only) --------------------
    def build_query_text(self, image_context: str, product_description: str) -> str:
        """
        Combine product description + OCR text for DB search.
        NOTE: This is not stored; used only for searching.
        """
        s = f"{product_description or ''} {image_context or ''}".lower()
        s = re.sub(r"[^a-z0-9\s\-\/\.\+]", " ", s)  # keep simple tokens
        s = re.sub(r"\s+", " ", s).strip()
        return s

    # -------------------- DB search --------------------
    def search_tariff_candidates(self, query_text: str, top_n: int = 10) -> List[Dict]:
        """
        Calls OpenAI.usp_Tariff_SearchCandidates(@query, @top) which returns rows with:
        hsn_8d, subheading_6d, heading_4d, chap_no, description, score (0..1)
        """
        if not query_text:
            return []
        rows = self.sql_helper.execute_stored_procedure(
            "OpenAI.usp_Tariff_SearchCandidates",
            (query_text, top_n)
        )
        out: List[Dict] = []
        for r in rows:
            # handle None scores safely
            try:
                score_val = float(getattr(r, "score", 0.0) or 0.0)
            except Exception:
                score_val = 0.0
            out.append({
                "hsn_8d": getattr(r, "hsn_8d", None),
                "subheading_6d": getattr(r, "subheading_6d", None),
                "heading_4d": getattr(r, "heading_4d", None),
                "chap_no": getattr(r, "chap_no", None),
                "description": getattr(r, "description", ""),
                "score": score_val,
            })
        # ensure sorted, highest score first
        out.sort(key=lambda d: (-(d.get("score") or 0.0), d.get("hsn_8d") or ""))
        return out

    def choose_hsn_from_candidates(self, candidates: List[Dict]) -> Tuple[str, float]:
        """Return (hsn_8d, score) if top candidate is acceptable; else ('', top_score)."""
        if not candidates:
            return "", 0.0
        top = candidates[0]
        code = (top.get("hsn_8d") or "").strip()
        score = float(top.get("score") or 0.0)
        if re.fullmatch(r"\d{8}", code) and score >= MIN_SQL_SCORE:
            return code, score
        return "", score

    # -------------------- LLM fallback --------------------
    def get_hsn_code_from_llm(self, image_context: str, product_description: str,
                              candidates: List[Dict]) -> Dict:
        """
        Ask LLM to classify when SQL match is weak. Returns dict:
        {
          "hsn_code": "84713010",
          "chapter": "84",
          "heading": "8471",
          "subheading": "847130",
          "description": "...",
          "justification": "...",
          "confidence": 0.82
        }
        """
        try:
            hints = [
                {
                    "hsn_8d": c.get("hsn_8d"),
                    "score": c.get("score"),
                    "snippet": (c.get("description") or "")[:200]
                }
                for c in (candidates[:5] if candidates else [])
                if c.get("hsn_8d")
            ]

            SYSTEM = (
                "You are an Indian HSN classifier for customs tariff. Follow the GRI, "
                "section/chapter notes, and choose the most specific 8-digit Indian HSN. "
                "Prefer specific headings to residual baskets. Consider principal function, "
                "material, and end-use. Return STRICT JSON with keys: "
                '{"hsn_code":string,"chapter":string,"heading":string,"subheading":string,'
                '"description":string,"justification":string,"confidence":number}. Only output JSON.'
            )

            user_payload = {
                "image_context": image_context,
                "product_description": product_description,
                "candidate_hints": hints
            }

            resp = openai.ChatCompletion.create(
                model="gpt-4-turbo",
                messages=[
                    {"role": "system", "content": SYSTEM},
                    {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False)}
                ],
                temperature=0.1
            )
            raw = resp["choices"][0]["message"]["content"].strip()
            self.logger.debug(f"LLM raw: {raw}")
            data = json.loads(raw)

            # normalize
            hsn = str(data.get("hsn_code", "")).replace(".", "").replace(" ", "")
            if not re.fullmatch(r"\d{8}", hsn):
                data["hsn_code"] = ""
            else:
                data["hsn_code"] = hsn

            try:
                c = float(data.get("confidence", 0))
                data["confidence"] = max(0.0, min(1.0, c))
            except Exception:
                data["confidence"] = 0.0

            return data

        except Exception as e:
            self.logger.error(f"LLM error: {e}")
            return {"hsn_code": "", "confidence": 0.0, "justification": f"LLM error: {e}"}

    # -------------------- main loop --------------------
    def process_files(self, company_id: int, file_type: str) -> None:
        """
        End-to-end:
         - Fetch pending rows
         - For each image:
            OCR -> save ImageOCR to DB
            Search DB (OCR + SQL description in-memory)
            If top score >= 0.8 -> accept
            Else -> call LLM
            Update HSNCode, TopSQLScore, LLMConfidence
            Move file & mark processed
        """
        try:
            rows = self.sql_helper.execute_stored_procedure(
                "OpenAI.usp_HSNCodeDetail_ProcessSearch",
                (company_id, file_type)
            )
            self.logger.info(f"Total files to process: {len(rows)}")
            if not rows:
                self.logger.info("No records found to process.")
                return

            hsn_code_ids = ",".join(str(row.HSNCodeId) for row in rows)
            self.sql_helper.execute_json_stored_procedure(
                "OpenAI.usp_HSNCodeDetail_ProcessAction",
                {"Action": "UpdateIsProcessing", "HSNCodeIds": hsn_code_ids}
            )
            self.logger.info("Marked HSNCodeIds as processing.")

            # Allowed image extensions
            img_exts = [
                e.strip().lower() for e in os.getenv(
                    "HSNCODE_IMAGE_EXTENSIONS", ".jpg,.jpeg,.png"
                ).split(",")
            ]

            for index, row in enumerate(rows, start=1):
                filename = row.FileName
                product_description = getattr(row, 'ProductDescription', '') or ''
                hsn_code_id = row.HSNCodeId

                self.logger.info(f"Processing file {index}/{len(rows)}: {filename}")
                if not filename.lower().endswith(tuple(img_exts)):
                    self.logger.warning(f"Skipping non-image file: {filename}")
                    continue

                jpg_path = os.path.join(self.input_folder, filename)
                if not os.path.exists(jpg_path):
                    self.logger.warning(f"File not found: {jpg_path}")
                    continue

                # --- 1) OCR & SAVE ImageOCR ---
                image_context = self.extract_visual_context_from_image(jpg_path)
                self.sql_helper.execute_json_stored_procedure(
                    "OpenAI.usp_HSNCodeDetail_ProcessAction",
                    {
                        "Action": "UpdateImageDescription",
                        "HSNCodeId": hsn_code_id,
                        "ImageOCR": image_context
                    }
                )

                # --- 2) SEARCH (OCR + SQL description, in-memory only) ---
                query_text = self.build_query_text(image_context, product_description)
                candidates = self.search_tariff_candidates(query_text, top_n=10)
                picked_hsn, top_score = self.choose_hsn_from_candidates(candidates)

                # --- 3) LLM fallback if needed ---
                final_hsn = picked_hsn
                llm_conf = None
                if not final_hsn:
                    llm_result = self.get_hsn_code_from_llm(image_context, product_description, candidates)
                    final_hsn = llm_result.get("hsn_code") or ""
                    llm_conf = llm_result.get("confidence")

                # --- 4) UPDATE DB with results ---
                if re.fullmatch(r"\d{8}", final_hsn):
                    self.sql_helper.execute_json_stored_procedure(
                        "OpenAI.usp_HSNCodeDetail_ProcessAction",
                        {
                            "Action": "UpdateHSNCode",
                            "HSNCode": final_hsn,
                            "HSNCodeId": hsn_code_id,
                            "TopSQLScore": float(top_score or 0.0),
                            "LLMConfidence": float(llm_conf) if llm_conf is not None else None
                        }
                    )
                    self.logger.info(f"HSN={final_hsn} (sql_score={top_score}, llm_conf={llm_conf})")
                else:
                    self.sql_helper.execute_json_stored_procedure(
                        "OpenAI.usp_HSNCodeDetail_ProcessAction",
                        {
                            "Action": "MarkUnclassified",
                            "HSNCodeId": hsn_code_id,
                            "TopSQLScore": float(top_score or 0.0),
                            "LLMConfidence": float(llm_conf) if llm_conf is not None else None
                        }
                    )
                    self.logger.warning(f"Unclassified (sql_score={top_score}, llm_conf={llm_conf})")

                # --- 5) Move file & mark processed ---
                try:
                    os.makedirs(self.output_folder, exist_ok=True)
                    dst = os.path.join(self.output_folder, filename)
                    if os.path.exists(dst):
                        os.remove(dst)
                    shutil.move(jpg_path, dst)
                except Exception as e:
                    self.logger.error(f"Move error for {filename}: {e}")

                self.sql_helper.execute_json_stored_procedure(
                    "OpenAI.usp_HSNCodeDetail_ProcessAction",
                    {"Action": "UpdateIsProcessed", "HSNCodeId": hsn_code_id}
                )

            # --- 6) Clear processing flags ---
            self.sql_helper.execute_json_stored_procedure(
                "OpenAI.usp_HSNCodeDetail_ProcessAction",
                {"Action": "Update_RemovingIsProcessing", "HSNCodeIds": hsn_code_ids}
            )
            self.logger.info("Removed processing flags.")

        except Exception as e:
            self.logger.error(f"An error occurred during processing: {e}")
