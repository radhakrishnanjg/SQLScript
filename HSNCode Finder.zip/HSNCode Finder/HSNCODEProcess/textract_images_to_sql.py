# file: hsn_textract_pipeline_json_sp.py
import os
import re
import json
import time
import logging
from pathlib import Path
from typing import Dict, List, Iterable

import boto3
from dotenv import load_dotenv

# Your helper: must expose execute_json_stored_procedure(proc_name: str, json_data: dict) -> None
from sql_helper import SQLHelper


class HSNTextractPipeline:
    def __init__(self) -> None:
        load_dotenv()

        # --- Config ---
        self.AWS_REGION = os.getenv("AWS_REGION", "ap-south-1")
        self.S3_BUCKET = os.getenv("S3_BUCKET")  # e.g., valuecart-tariff
        self.RAW_PREFIX = os.getenv("RAW_PREFIX", "tariff/2025-26/raw/")
        self.OUT_PREFIX = os.getenv("OUT_PREFIX", "tariff/2025-26/textract/")
        self.REQUEST_SLEEP_SEC = float(os.getenv("REQUEST_SLEEP_SEC", "0.15"))

        # Stored procedure name to receive JSON
        # e.g., OpenAI.usp_UpsertTariffLines_FromJson
        self.PROC_TARIFF_JSON = os.getenv(
            "PROC_TARIFF_JSON", "OpenAI.usp_UpsertTariffLines_FromJson"
        )

        if not self.S3_BUCKET:
            raise RuntimeError("S3_BUCKET env var not set.")

        # --- Logging ---
        self.logger = logging.getLogger(self.__class__.__name__)
        if not self.logger.handlers:
            logging.basicConfig(
                level=logging.INFO,
                format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            )

        # --- AWS Clients ---
        session = boto3.Session(region_name=self.AWS_REGION)
        self.s3 = session.client("s3")
        self.textract = session.client("textract")

        # --- Regex for codes ---
        self.HSN8_RE = re.compile(r"\b(\d{8})\b")
        self.HSN6_RE = re.compile(r"\b(\d{6})\b")
        self.HEAD4_RE = re.compile(r"\b(\d{4})\b")

        # --- SQL Helper (your wrapper) ---
        self.sql = SQLHelper()  # must connect internally (via its own env/DSN)

    # -----------------------
    # S3 list helpers
    # -----------------------
    def list_images(self, prefix: str = None) -> List[str]:
        """List all .jpeg/.jpg/.png under RAW_PREFIX (paginated)."""
        prefix = prefix or self.RAW_PREFIX
        keys: List[str] = []
        kwargs = {"Bucket": self.S3_BUCKET, "Prefix": prefix, "MaxKeys": 1000}
        while True:
            resp = self.s3.list_objects_v2(**kwargs)
            for obj in resp.get("Contents", []) or []:
                k = obj["Key"]
                if k.lower().endswith((".jpeg", ".jpg", ".png")):
                    keys.append(k)
            if resp.get("IsTruncated"):
                kwargs["ContinuationToken"] = resp.get("NextContinuationToken")
            else:
                break
        return keys

    def list_jsons(self, prefix: str = None) -> List[str]:
        """List *.json under OUT_PREFIX (paginated)."""
        prefix = prefix or self.OUT_PREFIX
        keys: List[str] = []
        kwargs = {"Bucket": self.S3_BUCKET, "Prefix": prefix, "MaxKeys": 1000}
        while True:
            resp = self.s3.list_objects_v2(**kwargs)
            for obj in resp.get("Contents", []) or []:
                k = obj["Key"]
                if k.lower().endswith(".json"):
                    keys.append(k)
            if resp.get("IsTruncated"):
                kwargs["ContinuationToken"] = resp.get("NextContinuationToken")
            else:
                break
        return keys

    # -----------------------
    # Process 1: JPEG → JSON
    # -----------------------
    def process1_images_to_textract_json(self) -> None:
        """
        Convert EVERY image under RAW_PREFIX into a Textract JSON under OUT_PREFIX.
        No 'force' or 'skip' guards by design (per your requirement).
        """
        images = self.list_images(self.RAW_PREFIX)
        if not images:
            self.logger.info(
                f"No images found under s3://{self.S3_BUCKET}/{self.RAW_PREFIX}"
            )
            return

        self.logger.info(f"Process 1: {len(images)} image(s) to process.")
        created = 0
        for i, img_key in enumerate(images, 1):
            stem = Path(img_key).stem
            out_key = f"{self.OUT_PREFIX}{stem}_textract.json"

            self.logger.info(f"[{i}/{len(images)}] Textract: {img_key}")
            resp = self.textract.analyze_document(
                Document={"S3Object": {"Bucket": self.S3_BUCKET, "Name": img_key}},
                FeatureTypes=["TABLES", "FORMS"],
            )
            self.s3.put_object(
                Bucket=self.S3_BUCKET,
                Key=out_key,
                Body=json.dumps(resp, ensure_ascii=False).encode("utf-8"),
                ContentType="application/json",
            )
            self.logger.info(f"Saved JSON → s3://{self.S3_BUCKET}/{out_key}")
            created += 1
            time.sleep(self.REQUEST_SLEEP_SEC)

        self.logger.info(f"Process 1 finished. Created: {created}")

    # -----------------------
    # Process 2: JSON → SQL (via stored proc)
    # -----------------------
    def process2_textract_jsons_to_db(self) -> None:
        """
        For each JSON in OUT_PREFIX:
         - read JSON from S3
         - parse tables
         - normalize rows
         - send a single JSON payload to your stored procedure
        """
        json_keys = self.list_jsons(self.OUT_PREFIX)
        if not json_keys:
            self.logger.info(
                f"No JSON files found under s3://{self.S3_BUCKET}/{self.OUT_PREFIX}"
            )
            return

        self.logger.info(f"Process 2: {len(json_keys)} JSON file(s) to load.")
        total_rows = 0
        for i, json_key in enumerate(json_keys, 1):
            self.logger.info(f"[{i}/{len(json_keys)}] {json_key}")
            try:
                payload = self._build_payload_for_sp(json_key)
                self.sql.execute_json_stored_procedure(self.PROC_TARIFF_JSON, payload)
                total_rows += len(payload.get("rows", []))
            except Exception as e:
                self.logger.error(f"ERROR: {json_key}: {e}", exc_info=True)
            time.sleep(self.REQUEST_SLEEP_SEC)

        self.logger.info(f"Process 2 finished. Total rows sent to SP: {total_rows}")

    # ---------- helpers for Process 2 ----------
    def _build_payload_for_sp(self, json_key: str) -> Dict:
        """Load Textract JSON, extract tables, normalize rows, return payload dict for SP."""
        obj = self.s3.get_object(Bucket=self.S3_BUCKET, Key=json_key)
        payload = json.loads(obj["Body"].read())

        # Textract analyze_document returns dict with 'Blocks'
        if isinstance(payload, dict) and "Blocks" in payload:
            blocks = payload["Blocks"]
        elif isinstance(payload, list):
            blocks = []
            for part in payload:
                blocks.extend(part.get("Blocks", []))
        else:
            raise ValueError("Unrecognized Textract JSON shape.")

        tables = list(self._extract_tables_from_blocks(blocks))
        page_hint = self._guess_image_key_from_json_key(json_key)
        chapter = self._guess_chapter_from_key(page_hint or json_key)
        rows = self._normalize_tariff_rows(
            tables, chapter_number=chapter, page_hint=page_hint or json_key
        )

        return {"source_key": json_key, "schedule_ref": "Customs Tariff 2025-26", "rows": rows}

    @staticmethod
    def _build_block_index(blocks: List[Dict]) -> Dict[str, Dict]:
        return {b["Id"]: b for b in blocks}

    def _extract_tables_from_blocks(self, blocks: List[Dict]) -> Iterable[List[List[str]]]:
        """Yield tables as 2D arrays (rows)."""
        by_id = self._build_block_index(blocks)
        for tbl in (b for b in blocks if b.get("BlockType") == "TABLE"):
            grid, max_r, max_c = {}, 0, 0
            for rel in tbl.get("Relationships", []):
                if rel.get("Type") != "CHILD":
                    continue
                for cid in rel.get("Ids", []):
                    cell = by_id.get(cid)
                    if not cell or cell.get("BlockType") != "CELL":
                        continue
                    r, c = cell.get("RowIndex", 0), cell.get("ColumnIndex", 0)
                    text_parts = []
                    for r2 in cell.get("Relationships", []):
                        if r2.get("Type") != "CHILD":
                            continue
                        for wid in r2.get("Ids", []):
                            blk = by_id.get(wid)
                            if blk and blk.get("BlockType") == "WORD":
                                text_parts.append(blk.get("Text", ""))
                    grid.setdefault(r, {})[c] = " ".join(text_parts).strip()
                    max_r, max_c = max(max_r, r), max(max_c, c)

            rows = [[grid.get(r, {}).get(c, "") for c in range(1, max_c + 1)]
                    for r in range(1, max_r + 1)]
            if rows:
                yield rows

    def _normalize_tariff_rows(
        self, tables: Iterable[List[List[str]]], chapter_number: int, page_hint: str
    ) -> List[Dict]:
        records: List[Dict] = []
        for rows in tables:
            if not rows:
                continue
            header = [c.lower() for c in rows[0]]
            code_idx = next((i for i, c in enumerate(header) if "code" in c or "hsn" in c or "heading" in c), 0)
            desc_idx = next((i for i, c in enumerate(header) if "desc" in c), 1 if len(rows[0]) > 1 else 0)

            for r in rows[1:]:
                if not any(r):
                    continue
                code_raw = (r[code_idx] if code_idx < len(r) else "")
                code_text = code_raw.replace(".", "").replace(" ", "")
                desc_text = r[desc_idx].strip() if desc_idx < len(r) else " ".join([c for c in r if c]).strip()
                if not desc_text and not code_text:
                    continue

                head4 = self.HEAD4_RE.match(code_text)
                sub6 = self.HSN6_RE.search(code_text)
                hsn8 = self.HSN8_RE.search(code_text)

                records.append({
                    "chap_no": chapter_number,
                    "heading_4d": head4.group(1) if head4 else None,
                    "subheading_6d": sub6.group(1) if sub6 else None,
                    "hsn_8d": hsn8.group(1) if hsn8 else None,
                    "description": desc_text,
                    "page_ref": page_hint
                })
        return records

    # ---------- utilities ----------
    def _guess_chapter_from_key(self, key: str) -> int:
        fname = Path(key).name
        m = re.search(r"chapter[_-]?(\d{1,2})", fname, re.IGNORECASE)
        if m:
            return int(m.group(1))
        m2 = re.search(r"(\d{2})", fname)
        return int(m2.group(1)) if m2 else 0

    @staticmethod
    def _guess_image_key_from_json_key(json_key: str) -> str:
        # OUT_PREFIX + <image_stem>_textract.json  -> RAW_PREFIX + <image_stem> (for audit)
        stem = Path(json_key).stem
        if stem.endswith("_textract"):
            stem = stem[:-9]
        return f"tariff/2025-26/raw/{stem}"


# # -----------------------
# # External runner helpers
# # -----------------------
# def run_by_file_type(file_type: str):
#     """
#     Call from outside (no argparse) with your strings:
#       - "TARIFFS3ImagesTOJSON" -> Process 1
#       - "TARIFFS3JSONTODB"     -> Process 2
#     """
#     worker = HSNTextractPipeline()
#     if file_type == "TARIFFS3ImagesTOJSON":
#         worker.process1_images_to_textract_json()
#     elif file_type == "TARIFFS3JSONTODB":
#         worker.process2_textract_jsons_to_db()
#     else:
#         raise ValueError(f"Unknown file_type: {file_type}")


# # Optional CLI wrapper (keep if you also want to run from terminal)
# if __name__ == "__main__":
#     import argparse
#     parser = argparse.ArgumentParser(description="HSN Textract Pipeline (Process 1 or 2)")
#     parser.add_argument("--file_type", choices=["TARIFFS3ImagesTOJSON", "TARIFFS3JSONTODB"], required=True)
#     args = parser.parse_args()
#     run_by_file_type(args.file_type)
