USE [JenniferProd]
GO

/****** Object:  Table [OpenAI].[tariff_lines]    Script Date: 08-10-2025 19:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[OpenAI].[tariff_lines]') AND type in (N'U'))
DROP TABLE [OpenAI].[tariff_lines]
GO

/****** Object:  Table [OpenAI].[HSNCodeDetailLog]    Script Date: 08-10-2025 19:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[OpenAI].[HSNCodeDetailLog]') AND type in (N'U'))
DROP TABLE [OpenAI].[HSNCodeDetailLog]
GO

/****** Object:  Table [OpenAI].[HSNCodeDetail]    Script Date: 08-10-2025 19:24:31 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[OpenAI].[HSNCodeDetail]') AND type in (N'U'))
DROP TABLE [OpenAI].[HSNCodeDetail]
GO

/****** Object:  Table [OpenAI].[HSNCodeDetail]    Script Date: 08-10-2025 19:24:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [OpenAI].[HSNCodeDetail](
	[HSNCodeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CompanyId] [int] NOT NULL,
	[FileType] [varchar](30) NOT NULL,
	[ObjectId] [varchar](300) NOT NULL,
	[ImageOCR] [varchar](4000) NULL,
	[ImageOCROn] [datetime] NULL,
	[ProductDescription] [varchar](4000) NOT NULL,
	[TopSQLScore] [decimal](5, 2) NULL,
	[LLMConfidence] [decimal](5, 2) NULL,
	[MaterialComposition] [varchar](100) NULL,
	[ProductSpecification] [varchar](100) NULL,
	[ProductEndUse] [varchar](100) NULL,
	[HSNCode] [varchar](20) NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL,
	[IsProcessed] [bit] NULL,
	[ProcessStartDate] [datetime] NULL,
	[IsProcessing] [bit] NULL,
	[IsRejected] [bit] NULL,
	[RejectedReason] [varchar](8000) NULL,
	[ProcessCompletedDate] [datetime] NULL,
	[IsDeleted] [bit] NULL,
	[DeletedBy] [int] NULL,
	[DeletedDate] [datetime] NULL
) ON [PRIMARY]
GO

/****** Object:  Table [OpenAI].[HSNCodeDetailLog]    Script Date: 08-10-2025 19:24:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [OpenAI].[HSNCodeDetailLog](
	[logID] [bigint] IDENTITY(1,1) NOT NULL,
	[CompanyId] [int] NOT NULL,
	[FileType] [varchar](30) NOT NULL,
	[HSNCodeId] [bigint] NOT NULL,
	[ActionTime] [datetime] NULL,
	[StackTrace] [varchar](max) NULL,
	[MessageText] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [OpenAI].[tariff_lines]    Script Date: 08-10-2025 19:24:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [OpenAI].[tariff_lines](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[chap_no] [int] NOT NULL,
	[heading_4d] [char](4) NULL,
	[subheading_6d] [char](6) NULL,
	[hsn_8d] [char](8) NULL,
	[description] [nvarchar](max) NOT NULL,
	[section_note_text] [nvarchar](max) NULL,
	[chapter_note_text] [nvarchar](max) NULL,
	[schedule_ref] [nvarchar](100) NULL,
	[page_ref] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


