 select * from OpenAI.HSNCodeDetail

 select * from OpenAI.HSNCodeDetailLog

delete OpenAI.HSNCodeDetail
insert into OpenAI.HSNCodeDetail(CompanyId,FileType,ObjectId,ProductDescription)
select 3 CompanyId,'HSNCODE'FileType,'B0CLGCBPGY.jpg' ObjectId,'256 GB USB 3.0 Flash Drive KOOTION Flash Drive 3.0 Thumb Drive Retractable 256G Memory Stick USB Drive Jump Drive Rugged with LED Indicator for Data Storage and Transfer'
ProductDescription

insert into OpenAI.HSNCodeDetail(CompanyId,FileType,ObjectId,ProductDescription)
select 3 CompanyId,'HSNCODE'FileType,'B01ANDA8GE.jpg' ObjectId,'Cmhoo XXL Professional Large Mouse Pad & 90cmx40cm Computer Game Mousepad (90x40 INDragon)' ProductDescription

