USE [JenniferProd]
GO

/****** Object:  StoredProcedure [OpenAI].[usp_UpsertTariffLines_FromJson]    Script Date: 08-10-2025 19:25:38 ******/
DROP PROCEDURE [OpenAI].[usp_UpsertTariffLines_FromJson]
GO

/****** Object:  StoredProcedure [OpenAI].[usp_Tariff_SearchCandidates]    Script Date: 08-10-2025 19:25:38 ******/
DROP PROCEDURE [OpenAI].[usp_Tariff_SearchCandidates]
GO

/****** Object:  StoredProcedure [OpenAI].[usp_HSNCodeDetail_ProcessSearch]    Script Date: 08-10-2025 19:25:38 ******/
DROP PROCEDURE [OpenAI].[usp_HSNCodeDetail_ProcessSearch]
GO

/****** Object:  StoredProcedure [OpenAI].[usp_HSNCodeDetail_ProcessAction]    Script Date: 08-10-2025 19:25:38 ******/
DROP PROCEDURE [OpenAI].[usp_HSNCodeDetail_ProcessAction]
GO

/****** Object:  StoredProcedure [OpenAI].[usp_HSNCodeDetail_ProcessAction]    Script Date: 08-10-2025 19:25:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE [OpenAI].[usp_HSNCodeDetail_ProcessAction]
@json varchar(max)
as
BEGIN 
Begin Try
	Begin Tran   
	
	set nocount on;  
 
	set @json=concat('[' ,@json , ']')   

	
	declare @Action  varchar(50) 
	declare @CompanyId  int
	declare @FileType  varchar(30) 
	declare @LoginId  varchar(30)  
	declare @HSNCodeId int
	
	
	SET @Action=JSON_VALUE(@json,'$[0].Action'); 
	SET @CompanyId=JSON_VALUE(@json,'$[0].CompanyId'); 
	SET @FileType=JSON_VALUE(@json,'$[0].FileType'); 
	SET @LoginId=JSON_VALUE(@json,'$[0].LoginId'); 

	SET @HSNCodeId=JSON_VALUE(@json,'$[0].HSNCodeId');  
	declare @HSNCodeIds varchar(max) 
	Declare @MessageText varchar(max)
	Declare @StackTrace varchar(max) ,  @HSNCode varchar(20), @TopSQLScore decimal(5,2), @LLMConfidence decimal(5,2)
	
	if(@Action='UpdateIsProcessing')
	begin   
		SET @HSNCodeIds=JSON_VALUE(@json,'$[0].HSNCodeIds'); 

		declare @ProcessStartDate datetime 
		SET @ProcessStartDate= SWITCHOFFSET(JSON_VALUE(@json,'$[0].ProcessStartDate'), '+05:30') ;  
		Update OpenAI.HSNCodeDetail set IsProcessing=1,ProcessStartDate=DATEADD(MINUTE,330,getdate())
		Where 1=1
		and HSNCodeId in (select value from dbo.fn_split(@HSNCodeIds,','))

		select 'File status : IsProcessing has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end   
	else if @Action='Update_RemovingIsProcessing'
	begin   
		SET @HSNCodeIds=JSON_VALUE(@json,'$[0].HSNCodeIds'); 

		Update OpenAI.HSNCodeDetail set Isprocessing=0 
		where 1=1
		and HSNCodeId in (select value from dbo.fn_split(@HSNCodeIds,','))

		select 'Removing IsProcessing has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end
	else if(@Action='UpdateIsProcessed')
	begin      

		Update OpenAI.HSNCodeDetail set IsProcessed=1,Isprocessing=0,ProcessCompletedDate= DATEADD(MINUTE,330,getdate()) 
		Where HSNCodeId=@HSNCodeId

		select 'File status : IsProcessed has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end  
	else  if(@Action='UpdateImageDescription')
	begin      
		
		declare @ImageOCR varchar(4000)
		SET @ImageOCR=JSON_VALUE(@json,'$[0].ImageOCR');  

		Update OpenAI.HSNCodeDetail set ImageOCR=left(isnull(@ImageOCR,''),4000),ImageOCROn=Getdate() 
		Where HSNCodeId=@HSNCodeId

		select 'HSNCode has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end 
	else  if(@Action='UpdateHSNCode')
	begin      
		SET @HSNCode=JSON_VALUE(@json,'$[0].HSNCode'); 
		SET @TopSQLScore=JSON_VALUE(@json,'$[0].TopSQLScore'); 
		SET @LLMConfidence=JSON_VALUE(@json,'$[0].LLMConfidence'); 

		Update OpenAI.HSNCodeDetail set HSNCode=@HSNCode,TopSQLScore=@TopSQLScore,LLMConfidence=@LLMConfidence
		Where HSNCodeId=@HSNCodeId

		select 'HSNCode has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end 
	else if(@Action='MarkUnclassified')
	begin       
		SET @HSNCode=JSON_VALUE(@json,'$[0].HSNCode'); 
		SET @TopSQLScore=JSON_VALUE(@json,'$[0].TopSQLScore'); 
		SET @LLMConfidence=JSON_VALUE(@json,'$[0].LLMConfidence'); 

		Update OpenAI.HSNCodeDetail set HSNCode=@HSNCode,TopSQLScore=@TopSQLScore,LLMConfidence=@LLMConfidence
		Where HSNCodeId=@HSNCodeId

		select 'HSNCode has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end 
	if(@Action='UpdateIsRejected')
	begin   

		Declare @RejectedReason varchar(8000)
		SET @RejectedReason=JSON_VALUE(@json,'$[0].RejectedReason'); 

		Update OpenAI.HSNCodeDetail set IsRejected=1,RejectedReason=@RejectedReason 
		Where HSNCodeId=@HSNCodeId

		select 'File status : IsRejected has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end   
	if(@Action='InsertInvoiceFileLog')
	begin    
		SET @StackTrace=JSON_VALUE(@json,'$[0].StackTrace');  
		SET @MessageText=JSON_VALUE(@json,'$[0].MessageText'); 

		Update OpenAI.HSNCodeDetail set IsProcessed=1,Isprocessing=0,IsRejected=1
		,RejectedReason='Wrong Pdf File uploaded.So System can''t possible to process!' 
		Where HSNCodeId=@HSNCodeId

		insert into OpenAI.HSNCodeDetailLog (CompanyId,FileType,HSNCodeId,ActionTime,StackTrace,MessageText)
		SELECT @CompanyId,@FileType,@HSNCodeId,getdate(),@StackTrace,@MessageText  

		select 'File status : IsRejected has been updated successfully' as Msg ,cast(1 as bit) as Flag
	end  
Commit
End Try
Begin Catch
	if @@TRANCOUNT > 0
	Begin
		rollback;

		insert into  Register.ErrorLog(CompanyDetailID,ScreenName,UniqueNumber,ErrorMessage,CreatedDate)
		select  null,'usp_HSNCodeDetail_ProcessAction not uploaded',@HSNCodeId,ERROR_MESSAGE(),GETDATE()

		select 'HSNCodeDetail Processing Failed. Please try again after sometime.!' as Msg ,cast(0 as bit) as Flag
	End
End Catch	

END
GO

/****** Object:  StoredProcedure [OpenAI].[usp_HSNCodeDetail_ProcessSearch]    Script Date: 08-10-2025 19:25:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- OpenAI.usp_HSNCodeDetail_ProcessSearch @companyId=3,@FileType='HSNCODE'
Create   PROCEDURE [OpenAI].[usp_HSNCodeDetail_ProcessSearch]
@CompanyId int ,
@FileType varchar(30)
as
BEGIN 
	
	set nocount on;
	
	declare @MaximumProcessLimit int 
	
	select @MaximumProcessLimit=DropdownValue from masters.dropdown where dropdowntype='AmazonInvoiceProcessLimit' 
	and DropDownDescription='MaximumProcessLimit' 
	 
	Select top (@MaximumProcessLimit) HSNCodeId, Objectid FileName  ,ProductDescription
	FROM  OpenAI.HSNCodeDetail  AS ch with(nolock)  
	where 1=1
	and isnull(IsProcessed,0)=0 and  isnull(IsProcessing,0)=0 and  isnull(IsDeleted,0)=0 
	and CompanyId=@CompanyId 
	and FileType =@FileType
	order  by ch.CreatedDate desc  

	set nocount off;
END
GO

/****** Object:  StoredProcedure [OpenAI].[usp_Tariff_SearchCandidates]    Script Date: 08-10-2025 19:25:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [OpenAI].[usp_Tariff_SearchCandidates]
    @query NVARCHAR(MAX),   -- keep MAX here if you like
    @top   INT = 10
AS
BEGIN
    SET NOCOUNT ON;

    -- FREETEXTTABLE doesn't accept NVARCHAR(MAX); use <= NVARCHAR(4000)
    DECLARE @q NVARCHAR(4000) = CONVERT(NVARCHAR(4000), LEFT(@query, 4000));

    -------------------------------------------------------------------
    -- Optional exact-code bias: look for 8/6/4 digit tokens in @q
    -- (STRING_SPLIT requires SQL Server 2016 SP1+)
    -------------------------------------------------------------------
    ;WITH tokens AS (
        SELECT TRIM(value) AS tok
        FROM STRING_SPLIT(@q, ' ')
    ),
    digits AS (
        SELECT
            TRY_CONVERT(INT, tok) AS d
        FROM tokens
        WHERE tok LIKE '%[0-9]%' AND LEN(tok) BETWEEN 4 AND 8
    ),
    exacts AS (
        SELECT tl.id, 100 AS score
        FROM OpenAI.tariff_lines tl
        WHERE EXISTS (
            SELECT 1
            FROM digits g
            WHERE (tl.hsn_8d IS NOT NULL AND tl.hsn_8d = RIGHT('00000000' + CAST(g.d AS VARCHAR(8)), 8))
               OR (tl.subheading_6d IS NOT NULL AND tl.subheading_6d = RIGHT('000000'   + CAST(g.d AS VARCHAR(6)), 6))
               OR (tl.heading_4d    IS NOT NULL AND tl.heading_4d    = RIGHT('0000'     + CAST(g.d AS VARCHAR(4)), 4))
        )
    ),
    ftx AS (
        SELECT K.[KEY] AS id,
               CAST(CASE WHEN K.[RANK] > 1000 THEN 100 ELSE (K.[RANK] / 10.0) END AS DECIMAL(5,2)) AS score
        FROM FREETEXTTABLE(OpenAI.tariff_lines, description, @q, @top) AS K
    )
    SELECT TOP (@top)
           tl.hsn_8d,
           tl.subheading_6d,
           tl.heading_4d,
           tl.chap_no,
           tl.description,
           CAST(ISNULL(e.score, 0) + ISNULL(f.score, 0) AS DECIMAL(5,2)) AS score
    FROM OpenAI.tariff_lines AS tl
    OUTER APPLY (SELECT score FROM exacts e WHERE e.id = tl.id) e
    OUTER APPLY (SELECT score FROM ftx    f WHERE f.id = tl.id) f
    WHERE ISNULL(e.score, 0) + ISNULL(f.score, 0) > 0
    ORDER BY score DESC, tl.hsn_8d ASC;
END
GO

/****** Object:  StoredProcedure [OpenAI].[usp_UpsertTariffLines_FromJson]    Script Date: 08-10-2025 19:25:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE [OpenAI].[usp_UpsertTariffLines_FromJson]
    @payload NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @schedule_ref NVARCHAR(100);
    DECLARE @source_key   NVARCHAR(500);

    SELECT
        @schedule_ref = JSON_VALUE(@payload, '$.schedule_ref'),
        @source_key   = JSON_VALUE(@payload, '$.source_key');

    ;WITH j AS (
        SELECT
            TRY_CAST(JSON_VALUE(js.value, '$.chap_no') AS INT)      AS chap_no,
            NULLIF(LTRIM(RTRIM(JSON_VALUE(js.value, '$.heading_4d'))),   '') AS heading_4d,
            NULLIF(LTRIM(RTRIM(JSON_VALUE(js.value, '$.subheading_6d'))), '') AS subheading_6d,
            NULLIF(LTRIM(RTRIM(JSON_VALUE(js.value, '$.hsn_8d'))),        '') AS hsn_8d,
            NULLIF(LTRIM(RTRIM(JSON_VALUE(js.value, '$.description'))),    '') AS description,
            NULLIF(LTRIM(RTRIM(JSON_VALUE(js.value, '$.page_ref'))),       '') AS page_ref
        FROM OPENJSON(@payload, '$.rows') AS js
    ),
    -- normalize keys to avoid dup matches (collapse whitespace)
    j_norm AS (
        SELECT
            chap_no,
            heading_4d,
            subheading_6d,
            hsn_8d,
            description,
            page_ref,
            -- normalized keys used for matching/dedup
            ISNULL(hsn_8d, '')	AS hsn_8d_norm,
            CAST(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(description)), CHAR(13), ' '), CHAR(10), ' '), '  ', ' ') AS NVARCHAR(MAX)) AS desc_norm
        FROM j
        WHERE description IS NOT NULL  -- ignore fully blank descriptions
    ),
    src AS (
        SELECT
            chap_no,
            heading_4d,
            subheading_6d,
            hsn_8d,
            description,
            page_ref,
            hsn_8d_norm,
            desc_norm,
            ROW_NUMBER() OVER (
                PARTITION BY hsn_8d_norm, desc_norm
                ORDER BY
                    -- prefer the row with the most specific code info
                    CASE WHEN hsn_8d IS NOT NULL THEN 3
                         WHEN subheading_6d IS NOT NULL THEN 2
                         WHEN heading_4d IS NOT NULL THEN 1
                         ELSE 0 END DESC,
                    chap_no DESC,
                    page_ref ASC
            ) AS rn
        FROM j_norm
    )
    MERGE OpenAI.tariff_lines WITH (HOLDLOCK) AS tgt
    USING (
        SELECT chap_no, heading_4d, subheading_6d, hsn_8d, description, @schedule_ref AS schedule_ref, page_ref,
               hsn_8d_norm, desc_norm
        FROM src
        WHERE rn = 1   -- <<< ensure at most one source row per natural key
    ) AS s
    ON (
        ISNULL(tgt.hsn_8d, '') = s.hsn_8d_norm
        AND LTRIM(RTRIM(tgt.description)) = s.desc_norm
    )
    WHEN MATCHED THEN
        UPDATE SET
            tgt.chap_no       = s.chap_no,
            tgt.heading_4d    = s.heading_4d,
            tgt.subheading_6d = s.subheading_6d,
            tgt.schedule_ref  = s.schedule_ref,
            tgt.page_ref      = s.page_ref
    WHEN NOT MATCHED THEN
        INSERT (chap_no, heading_4d, subheading_6d, hsn_8d, description, schedule_ref, page_ref)
        VALUES (s.chap_no, s.heading_4d, s.subheading_6d, s.hsn_8d, s.description, s.schedule_ref, s.page_ref);
END
GO


